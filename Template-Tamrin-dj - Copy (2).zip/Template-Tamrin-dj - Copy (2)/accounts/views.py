    
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views.generic import CreateView
from accounts.forms import CreateUserForm
from django.contrib.auth import login, authenticate, logout
from .forms import *
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import PasswordResetView
from django.core.mail import send_mail, BadHeaderError
from django.http import HttpResponse
from django.contrib.auth.forms import PasswordResetForm
from django.contrib.auth.models import User
from django.template.loader import render_to_string
from django.db.models.query_utils import Q
from django.contrib.auth.tokens import default_token_generator
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
        
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        try:
            username = User.objects.get(email=username).username
        except User.DoesNotExist:
            username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)

        if user is not None:
            login(request, user)
            messages.success(request,"با موفقیت وارد شدید!")
            return redirect('/')
        else:
            messages.error(request,'اطلاعات به درستی وارد نشده است ، لطفا مجدد تلاش کنید!')
    return render(request, "accounts/login.html")
        


def signup_view(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                messages.success(request, 'حساب کاربری شما با موفقیت ساخته شد!')
                return redirect('/')
        form = CreateUserForm()
        context = {'form':form}
        return render(request, 'accounts/signup.html', context)
    else:
        return redirect('/')
    

@login_required
def logout_view(request):
    if request.user.is_authenticated:
        logout(request)
    messages.success(request, 'با موفقیت خارج شدید!')
    return redirect('/')
