from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from django.contrib import messages
from django.core.exceptions import ValidationError

class LoginForm(AuthenticationForm):
  #username = forms.CharField(max_length = 255)
  email = forms.EmailField(widget=forms.TextInput(attrs={'autofocus': True})) 
  #password = forms.CharField(max_length = 255)
  
  #class Meta:
    #model = User
    #fields = ['username', 'email', 'password']   


class CreateUserForm(UserCreationForm):
  #username = forms.CharField(required=True, max_length=30, ) 
  email = forms.EmailField(max_length=200, help_text='Required')    
  
  class Meta:
    model = User
    fields = ['username', 'email', 'password1', 'password2']
    
    
    
