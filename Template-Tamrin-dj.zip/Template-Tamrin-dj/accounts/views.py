'''from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from accounts.forms import CreateUserForm'''

'''def login_view(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            form = AuthenticationForm(request=request, data=request.POST)
            if form.is_valid():
                username = form.cleaned_data.get('username')
                password = form.cleaned_data.get('password')
                user = authenticate(request, username=username, password = password)
                messages.success(request,f'با موفقیت وارد شدید!')

                if user is not None:
                    login(request, user)
                    return redirect('accounts:profile')
            
        form = AuthenticationForm()
        context = {'form':form}
        return render(request, 'accounts/login.html', context)
    else:
        return redirect('/')


@login_required(login_url="/accounts/login")
def logout_view(request):
    logout(request)
    messages.success(request,'با موفقیت خارج شدید!')
    return redirect('/')




def signup_view(request):
    form = CreateUserForm()
    if request.method == "POST":
        form = CreateUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f'حساب شما با موفقیت ساخته شد!')
            return redirect('accounts:profile')


    context = {'form': form}
    return render(request, 'accounts/signup.html', context)


@login_required(login_url="/accounts/login")
def profile_view(request):
    return render(request, 'accounts/profile.html')'''


from django.shortcuts import render, redirect   
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views.generic import CreateView
from accounts.forms import CreateUserForm
from django.contrib.auth import login, authenticate
from django.contrib import messages
from .forms import *



'''class SignUpView(CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy("login")
    template_name = "registration/signup.html"'''

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user  = authenticate(request, username = username, password = password)
        if user is not None:
            login(request, user)
            messages.success(request, 'ورود شما با موفقیت انجام شد!')
            return redirect('/')
    return render(request,'accounts/login.html')
            



def signup(request):
    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            #user = authenticate(request, username = username, password = password)
            login(request, user, backend='django.contrib.auth.backends.ModelBackend')
            messages.success(request, 'حساب کاربری شما با موفقیت ساخته شد!')
            return redirect('/')
    else:
        form = CreateUserForm()
    return render(request, 'registration/signup.html', {'form': form})